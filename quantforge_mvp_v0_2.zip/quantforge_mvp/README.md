# QuantForge MVP v0.2

A zero-dependency static prototype for generating starter TradingView Pine Script v6 templates.

## Run locally
Open `index.html` in a modern browser. No build step or API key is required.

## Included
- Moving-average crossover indicator template
- Moving-average crossover strategy/backtest template
- RSI threshold indicator template
- Adjustable parameters, copy button and `.pine` download
- Responsive landing page and risk/backtest disclaimers

## Publish free (GitHub Pages)
1. Create/sign into a GitHub account.
2. Create a new **public** repository named `quantforge`.
3. Upload `index.html` to the repository root and commit.
4. Open repository Settings → Pages.
5. Under Build and deployment, choose deploy from a branch, select `main` and `/ (root)`, then Save.
6. Wait for the deployment URL shown in Settings → Pages.

GitHub Pages is for static websites. Do not put API keys, passwords, private user data, or payment secrets in this repository. A public repository exposes its source code.

Alternative: Cloudflare Pages can deploy a static HTML site. Check provider terms and current free-tier limits before relying on them.

## Current limitations
This is a template generator, not a real AI service. It does not compile or validate Pine Script on TradingView, fetch market data, authenticate users, save projects to a cloud account, or charge subscriptions.

## Safe next architecture
Browser frontend → server-side API endpoint → model provider. Keep API keys server-side, validate inputs, rate-limit requests, cap usage/costs, and log errors without storing unnecessary sensitive data.

For accounts and recurring billing, add authentication and a payment provider with subscription webhooks. Verify paid status on the server before granting features. Never trust a price or subscription flag supplied by the browser. Add privacy policy, terms, refund/cancellation information, and contact details before launch.

## Product caution
Backtests are hypothetical. Fees, slippage, data quality, repainting, lookahead bias, selection bias and overfitting can produce misleading results. Generated code must be independently reviewed and tested; do not promise returns or treat output as financial advice.
